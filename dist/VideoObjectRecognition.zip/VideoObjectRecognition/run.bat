@echo off
setlocal EnableDelayedExpansion

cd /d "%~dp0"

echo === NodeXL Video Object Recognition ===
echo Working directory: %CD%
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not on PATH.
    echo Install Python 3.10+ from https://www.python.org/downloads/ and tick
    echo "Add python.exe to PATH" during setup, then re-run this script.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo Found Python: !PYVER!
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating virtual environment in .venv\ ...
    python -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        echo.
        pause
        exit /b 1
    )

    echo [2/3] Upgrading pip and installing dependencies ^(this can take a minute^)...
    call ".venv\Scripts\activate.bat"
    python -m pip install --upgrade pip
    if errorlevel 1 (
        echo [ERROR] pip upgrade failed.
        echo.
        pause
        exit /b 1
    )
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Dependency install failed. See messages above.
        echo.
        pause
        exit /b 1
    )
) else (
    echo [1/3] Reusing existing virtual environment.
    call ".venv\Scripts\activate.bat"
    echo [2/3] Skipping install ^(delete .venv\ to force a fresh install^).
)

echo [3/3] Launching app. Press 'q' in the video window to stop.
echo.
python video_object_recognition.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if not "%EXITCODE%"=="0" (
    echo [ERROR] App exited with code %EXITCODE%. See messages above.
) else (
    echo App exited cleanly.
)
echo.
pause
endlocal
