@echo off
setlocal EnableDelayedExpansion

cd /d "%~dp0"

REM Put the virtual environment OUTSIDE the app folder. If the app lives in a
REM cloud-synced folder (Dropbox, OneDrive, iCloud), the sync agent locks files
REM mid-write and pip install fails with WinError 32. %LOCALAPPDATA% is local-
REM only and never synced.
set "VENV_DIR=%LOCALAPPDATA%\NodeXL-VideoObjectRecognition\venv"

echo === NodeXL Video Object Recognition ===
echo Working directory: %CD%
echo Virtual environment: %VENV_DIR%
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python is not on PATH.
    echo Install Python 3.10+ from https://www.python.org/downloads/ and tick
    echo "Add python.exe to PATH" during setup, then re-run this script.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo Found Python: !PYVER!
echo.

if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo [1/3] Creating virtual environment...
    python -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment at %VENV_DIR%.
        echo.
        pause
        exit /b 1
    )
) else (
    echo [1/3] Reusing existing virtual environment.
)

call "%VENV_DIR%\Scripts\activate.bat"

echo [2/3] Ensuring dependencies are installed ^(fast if already satisfied^)...
python -m pip install --upgrade pip >nul 2>nul
REM pip upgrade is best-effort — never fail the run on it.

python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Dependency install failed. See messages above.
    echo If this persists, delete "%VENV_DIR%" and re-run.
    echo.
    pause
    exit /b 1
)

echo [3/3] Launching app. Press 'q' in the video window to stop.
echo.
python video_object_recognition.py %*
set EXITCODE=%ERRORLEVEL%

echo.
if not "%EXITCODE%"=="0" (
    echo [ERROR] App exited with code %EXITCODE%. See messages above.
) else (
    echo App exited cleanly.
)
echo.
pause
endlocal
